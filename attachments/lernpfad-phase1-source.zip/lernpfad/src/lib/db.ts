import Dexie, { type Table } from 'dexie';
export interface StudyLog { id?:number; date:string; kind:string; planned:number; actual:number; completed:boolean; focus?:number }
export interface Card { id?:number; german:string; english:string; article?:'der'|'die'|'das'; plural?:string; example:string; due:string; interval:number; ease:number; reps:number }
class LernpfadDB extends Dexie { logs!:Table<StudyLog>; cards!:Table<Card>; constructor(){super('lernpfad');this.version(1).stores({logs:'++id,date,kind,completed',cards:'++id,german,due'});} }
export const db=new LernpfadDB();
