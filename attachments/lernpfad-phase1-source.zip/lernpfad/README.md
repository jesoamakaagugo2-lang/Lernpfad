# Lernpfad

A mobile-first German A1–B1 learning PWA. Phase 1 scaffold: dashboard, local-first Pomodoro study timer, A1 Unit 1 lesson player, starter vocabulary deck and Supabase schema.

## Run locally

1. Install Node.js 20+.
2. `npm install`
3. Copy `.env.example` to `.env` and add the Supabase project URL and anon/publishable key (optional for the local-first prototype; never add a service-role key to the frontend).
4. `npm run dev`

## Supabase setup

Create a Supabase project, then run `supabase/migrations/0001_initial_schema.sql` in the SQL Editor or with the Supabase CLI. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` to local `.env` and Netlify environment variables. The current UI stores flashcards and session logs locally; authenticated cloud sync is the next integration step. RLS policies are included in the migration.

## Netlify

Build command: `npm run build`; publish directory: `dist`. Connect this repository to Netlify for continuous deployment. `.netlify` is ignored by Git.

## Current scope

- Intensive track default (10 weeks, 5 hours/day, 10 blocks/day).
- Dashboard, focus timer and break controls.
- A1 Unit 1 original lessons and practice.
- Local flashcard review and browser persistence via IndexedDB.
- Responsive layout and PWA manifest.

## Important MVP limitations

The 10-week target is an ambitious study plan, not a guarantee of CEFR B1 attainment. Timer logs and cards are currently local to the browser. Supabase schema is provided but account creation and cloud sync are not yet wired. Audio playback, real speech recording, full offline service-worker caching, and the rest of A1 Units 2–3 are follow-on tasks.
